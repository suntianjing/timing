<template>
    <div class="hp-wrapper">
        <div class="notice">
            <span class="title">官方公告</span>
            <span class="description">为什么你的作品缺乏视觉焦点？用实战案例为你分析.</span>
            <span class="more">了解详情</span>
        </div>
        <div class="numbers">
          <el-card shadow="hover" v-for="item,index in numberList" :key="index">
            <div class="card-left">
              <img :src="item.iconUrl" alt="">
            </div>
            <div class="card-right">
              <h2>{{item.numbers}}</h2>
              <p>{{item.brief}}</p>
            </div>
          </el-card>
        </div>
        <div class="diary">
          <el-tabs v-model="activeName">
            <el-tab-pane label="付费Live（12）" name="first">
              暂无Live
            </el-tab-pane>
            <el-tab-pane label="音频&图文专辑（4）" name="second">
              暂无专辑
            </el-tab-pane>
          </el-tabs>
        </div>
    </div>
</template>

<script>

export default {
  name: 'HomePage',
  data(){
    return{
      activeName:'first',
      numberList:[
        {
          iconUrl: require("../../assets/img/care-icon.png"),
          numbers:'50,541',
          brief:'昨日新增关注数'
        },
        {
          iconUrl: require("../../assets/img/fans-icon.png"),
          numbers:'3,212',
          brief:'粉丝总数'
        },
        {
          iconUrl: require("../../assets/img/buy-icon.png"),
          numbers:'4,532',
          brief:'购买总数（人次）'
        },
        {
          iconUrl: require("../../assets/img/earning-icon.png"),
          numbers:'67,193',
          brief:'总收益（T币）'
        }
      ]
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5
border-color = #e6e6e6

.hp-wrapper
  width 100%
  height 100%
  display flex
  flex-direction column
  justify-content space-between

.notice
  height 30px
  line-height 30px
  background-color #fff
  border 1px solid border-color
  border-radius 4px
  font-size 14px
  padding 10px
  .title
    display inline-block
    background-color #ffc524
    color #fff
    padding 0 6px
  .description
    padding-left 10px
  .more
    color theme-color
    cursor pointer
    &:hover 
      color #00ffbf

.numbers
  margin 20px 0
  height 100px
  display flex
  justify-content space-between
  .el-card
    width 230px
    .el-card__body
      display flex
      .card-left
        width 55px
        height 55px
        margin-right 20px
        img 
          width 55px
          height 55px
      .card-right
        display flex
        flex-direction column
        justify-content space-between
        p
          font-size 14px
          color #4b4b4b99

.diary
  background-color #fff
  border 1px solid border-color
  border-radius 4px
  height 100%
  padding 20px
  #tab-first
    padding-left 16px
  .el-tabs__item.is-active 
    color theme-color
  .el-tabs__active-bar
    background-color theme-color
    height 4px
    border-radius 5px
  .el-tabs__item:hover
    color theme-color
</style>
