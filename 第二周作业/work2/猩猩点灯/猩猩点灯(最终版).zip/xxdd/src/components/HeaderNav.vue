<template>
  <div class="header-nav container">
    <div class="logo">
      <a href="javascript:0">
        <img src="../assets/img/logo.png" alt="">
        <h1>猩猩点灯</h1>
      </a>
    </div>
    <div class="user">
      <div class="bell">
        <el-tooltip effect="dark" content="消息通知" placement="bottom">
            <el-badge :value="12">
              <i class="el-tooltip el-badge el-icon-bell message"></i>
            </el-badge>
        </el-tooltip>
      </div>
      <div class="avatar">
        <el-dropdown size="medium">
          <img src="../assets/img/avatar.jpg" alt="">
          <el-dropdown-menu slot="dropdown" class="dropdown-menu">
            <el-dropdown-item class="dropdown-item">
              <img class="identify" src="../assets/img/identify.png" alt="">
              <span>认 证</span>
            </el-dropdown-item>
            <el-dropdown-item divided class="dropdown-item">
              <img class="exit" src="../assets/img/exit.png" alt="">
              <span>退出登录</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HeaderNav',
  props: {
    
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5
.header-nav
  height 60px
  display flex
  justify-content space-between
  align-items center
  .logo
    display flex
    justify-content space-between
    height 60px
    line-height 60px
    a
      display flex
      img
        display block
        margin auto 0
        width 30px
        height 30px
        padding-right 6px
      h1
        display inline-block
        color theme-color
        font-size 20px
  .user
    display flex
    justify-content space-between
    align-items center
    height 60px
    line-height 60px
    .bell
      width 60px
      height 60px;
      text-align center
      font-size 24px
      padding-right 20px
      .message
        cursor pointer
      .el-badge__content
        top 30%
    .avatar
      width 36px
      height 36px
      line-height 36px
      border-radius 50%
      border 1px solid #848484
      img
        width 100%
        height 100%

.dropdown-menu
  .dropdown-item
    height 34px
    line-height 34px
    font-size 14px
    &:hover
      color theme-color
      background-color theme-hover-color
    .identify,.exit
      width 16px
      height 16px
      padding-right 8px
      vertical-align -8%
</style>
