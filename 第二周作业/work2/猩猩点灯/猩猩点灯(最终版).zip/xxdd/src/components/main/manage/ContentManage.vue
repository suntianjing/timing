<template>
    <div class="wrapper cm-wrapper">
        <el-tabs v-model="activeName">
          <el-tab-pane :label="'学习日记（'+ diaryTotal +'）'" name="first">
            <div class="title">
              <span class="title-main">在Timing中，用户会用“学习日记”来记录学习历程、分享学习经验，“学习日记”有 文字+图片 和 文字+视频 两种样式。一篇好的“学习日记”，能够获得大量的曝光，吸引更多人的关注。</span>
              <span class="title-more">了解更多>></span>
            </div>
            <div class="diary-list">
              <div class="list-item" v-for="item,index in diaryList" :key="index">
                <div class="avatar">
                  <img :src="item.avatar" alt="">
                </div>
                <div class="user">
                  <div class="name">{{item.name}}</div>
                  <div class="time">{{item.time}}</div>
                  <div class="brief">{{item.brief}}</div>
                  <div class="pic">
                    <img :src="item1" alt="" v-for="item1,index1 in item.pic" :key="index1">
                  </div>
                  <div class="act">
                    <div class="like"><i class="el-icon-thumb"><span>{{item.likeNum}}</span></i></div>
                    <div class="comment"><i class="el-icon-chat-round"><span>{{item.commentNum}}</span></i></div>
                    <div class="share"><i class="el-icon-share"><span>{{item.shareNum}}</span></i></div>
                  </div>
                  <el-divider></el-divider>
                </div>
                <div class="delete" @click="deleteEvent(item.id)"><i class="el-icon-delete"></i></div>
              </div>
            </div>
          </el-tab-pane>

          <!-- 长视频标签 -->
          <el-tab-pane :label="'长视频（'+ videoTotal +'）'" name="second">
            暂无长视频
          </el-tab-pane>
        </el-tabs>
        <el-button class="publish-diary">发布学习日记</el-button>
        <el-pagination small :pager-count="pagerCount"  @current-change="handleCurrentChange" background layout="prev, pager, next" :total="diaryTotal"></el-pagination>
    </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'ContentManage',
  created(){
    this.getDiaryList();
  },
  data(){
    return{
      activeName:'first',
      diaryTotal: 0,
      videoTotal: 0,
      diaryList: [],
      pageIndex: 1,
      pagerCount: 5
    }
  },
  methods:{
    getDiaryList(){
      axios.post('/api/get/diary',{
          pageIndex: this.pageIndex,
          pageSize: 3
      }).then(res => {
        this.diaryList = res.data.list;
        this.diaryTotal = res.data.total;
      });
    },
    handleCurrentChange(val){
      this.pageIndex = val;
      this.getDiaryList();
    },
    deleteEvent(val){
      axios.post('/api/delete/diary',{
        id: val,
        pageIndex: this.pageIndex,
        pageSize: 3
      }).then(res => {
        this.diaryList = res.data.list;
        this.diaryTotal = res.data.total;
      });
    }
  }
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5

.cm-wrapper
  position relative
.publish-diary
  background-color theme-color
  color #fff
  position absolute
  right 0
  top 0
  margin 10px 20px 0 0
  z-index 1
  &:hover
    background-color theme-color
    color #fff
  &:focus
    background-color theme-color
    border-color theme-color
    color #fff
.title
  color: #868686
  font-size 14px
  .title-more
    cursor pointer
    color theme-color
.list-item
  margin-top 10px
  display flex
  .avatar
    width 32px
    height 32px  
    img 
      width 100%
      border-radius 50%
  .user
    width 100%
    margin-left 10px
    .name
      font-size 14px
    .time
      margin-top 3px
      font-size 12px
      color #8b8b8b
    .brief
      margin 5px 0
      font-size 12px
    .pic
      display flex
      img
        padding-right 10px
        width 100px
        height 100px
    .act
      margin-top 10px
      font-size 12px
      color: #8b8b8b
      display flex
      i
        cursor pointer
        margin-right 10px
        span 
          padding-left 5px
        &:hover
          color theme-color
    .el-divider
      margin-top 10px
      margin-bottom 0
  .delete
    cursor pointer
    height 20px
    &:hover
      color theme-color

#tab-first
  padding-left 16px
.el-tabs__item.is-active 
  color theme-color
.el-tabs__active-bar
  background-color theme-color
  height 4px
  border-radius 5px
.el-tabs__item:hover
  color theme-color

.el-pagination
  position absolute
  display inline-block
  bottom 10px
  right 0
.el-pagination.is-background .el-pager li:not(.disabled).active
  background-color theme-color
.el-pagination.is-background .el-pager li:not(.disabled):hover
  color theme-color
.el-pagination.is-background .el-pager li:not(.disabled).active:hover
  color #fff
</style>
