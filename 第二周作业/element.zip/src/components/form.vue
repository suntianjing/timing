<template>
  <div>
    <el-row>
      <el-col :span="24">
        <div class="grid-content bg-purple-dark"></div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'aform',


  data() {
    return {
      msg: 'xiixixixix'
    };
  },

  mounted() {

  },

  methods: {},
};
</script>

<style>
.bg-purple-dark {
  background: #99a9bf;
  height: 200px;
}

</style>