<template>
  <div id="app">
    <el-container class="mainer" >
      <el-header class="header-wrapper"><HeaderNav /></el-header>
      <el-container class="container">
        <el-aside width="200px" class="aside-wrapper"><AsideNav @togglePage="togglePage" /></el-aside>
        <el-main><MainContent :sendData="toPage"/></el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import HeaderNav from './components/HeaderNav.vue'
import AsideNav from './components/AsideNav.vue'
import MainContent from './components/MainContent.vue'

export default {
  name: 'App',
  data(){
    return{
      toPage: "HomePage",
    }
  },
  components: {
    HeaderNav,AsideNav,MainContent
  },
  methods: {
    togglePage(key){
      switch(key){
        case '1':
          this.toPage = 'HomePage';
          break;
        case '2-1':
          this.toPage = 'ContentManage';
          break;
        case '2-2':
          this.toPage = 'UserManage';
          break;
        case '3-1':
          this.toPage = 'Support';
          break;
        case '3-2':
          this.toPage = 'Answer';
          break;
        case '3-3':
          this.toPage = 'HoldLive';
          break;
        case '4-1':
          this.toPage = 'Publish';
          break;
        case '4-2':
          this.toPage = 'HoldCostLive';
          break;
        case '5':
          this.toPage = 'MyAssets';
          break;
        case '6':
          this.toPage = 'MyNetDisk';
          break;
      }
    }
  }
}
</script>

<style lang="stylus">
*
  margin 0
  padding 0
body,html 
  width 100%
  height 100%
  background-color #f7f9fa
#app
  height 100%
  width 100%
  background-color #f7f9fa
  a
    text-decoration none
  .mainer
    height 100%
    .header-wrapper
      background-color #fff
      box-shadow: 0 1px 3px 1px rgba(0, 0, 0, 0.1)
    .aside-wrapper
      height 100%
      padding 20px 20px 20px 0

.container
  width 1200px
  margin 0 auto
</style>
