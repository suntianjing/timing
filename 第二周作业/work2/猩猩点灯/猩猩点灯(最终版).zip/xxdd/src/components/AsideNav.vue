<template>
    <div class="aside">
        <el-menu default-active="1" class="menu" :default-openeds="openeds" active-text-color="#00c896" @select="handleSelect">
            <el-menu-item index="1">
                <i class="iconfont icon-zhuyecanting"></i>
                <span slot="title">主页</span>
            </el-menu-item>
            <el-submenu index="2">
                <template slot="title">
                    <i class="iconfont icon-dashboard-line"></i>
                    <span>管理</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="2-1">内容管理</el-menu-item>
                    <el-menu-item index="2-2">个人主页管理</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
            <el-submenu index="3">
                <template slot="title">
                    <i class="iconfont icon-homenav6"></i>
                    <span>涨粉</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="3-1">赞助自习室</el-menu-item>
                    <el-menu-item index="3-2">答疑</el-menu-item>
                    <el-menu-item index="3-3">举办live</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
            <el-submenu index="4">
                <template slot="title">
                    <i class="iconfont icon-zhangben"></i>
                    <span>创收</span>
                </template>
                <el-menu-item-group>
                    <el-menu-item index="4-1">发布专辑</el-menu-item>
                    <el-menu-item index="4-2">举办付费Live</el-menu-item>
                </el-menu-item-group>
            </el-submenu>
            <el-menu-item index="5">
                <i class="iconfont icon-zichan-xian"></i>
                <span slot="title">我的资产</span>
            </el-menu-item>
            <el-menu-item index="6">
                <i class="iconfont icon-wangpan"></i>
                <span slot="title">我的网盘</span>
            </el-menu-item>
        </el-menu>
    </div>
</template>

<script>
export default {
  name: 'AsideNav',
  props: {
    
  },
  data() {
    return {
      openeds: ['2','3','4']
    }
  },
  methods:{
      handleSelect(key){
          this.$emit('togglePage',key);
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5
border-color = #e6e6e6

.aside
    height 100%
    width 190px
    border-radius: 6px
    overflow: hidden
    border: 1px solid border-color
    box-sizing border-box

.menu
    height 100%
    border-right none
    .el-menu-item
        &:hover
            background-color #fff
        &:focus
            background-color #fff
        height 50px
        line-height 50px
        i
            padding-right 10px
    .el-submenu
        i
            padding-right 10px
    .el-menu-item-group
        .el-menu-item
            &:hover
                background-color theme-hover-color
                color theme-color
            &:focus
                background-color #fff
            height 32px
            line-height 32px
            color #4b4b4b99
            &.is-active:before
                top 0

.el-menu-item-group__title
    padding 0
.el-submenu__title
    &:hover
        background-color #fff
    height 50px
    line-height 50px
.el-menu-item.is-active:before
    content ""
    position absolute
    top 10px
    left 0
    height 32px
    width 3px
    background theme-color
    border-bottom-right-radius 4px
    border-top-right-radius 4px
</style>
