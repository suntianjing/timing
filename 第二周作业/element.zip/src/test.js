var ages = [32, 33, 16, 40];
var datalist = ['1214','3435','5768']

function checkAdult(age) {
    return age >= 18;
}

function check(data){
    return data.include('1214')
}

// console.log(ages.filter(checkAdult))
console.log(datalist.filter(check))
