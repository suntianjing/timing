<template>
    <div>
        
    </div>
</template>

<script>
export default {
    name: 'ElementNext',

    

    data() {
        return {
            
        };
    },

    mounted() {
        
    },

    methods: {
        
    },
};
</script>

<style scoped>

</style>