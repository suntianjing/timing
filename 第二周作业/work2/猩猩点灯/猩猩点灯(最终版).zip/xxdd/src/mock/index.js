import Mock from 'mockjs'

const Random = require('mockjs').Random;

const {diaryList} = Mock.mock({
    'diaryList|1-100': [
        {
            "id": "@increment(1)",
            "avatar": Random.image('32x32'),
            "name": /^[A-Z][a-z]{4,8}\ [A-Z][a-z]{4,8}/,       
            "time": "@date(yyyy-MM-dd hh:mm)",
            "brief": "@csentence(50,100)",
            "pic|1-4": [Random.image('100x100')],
            "likeNum|1-9999": 1,
            "commentNum|1-999": 1,
            "shareNum|1-99": 1,
        }
    ]
})

Mock.mock('/api/get/image','post')
Mock.mock('/api/get/idcard-image','post')

Mock.mock('/api/get/diary','post',(options)=>{
    const body = JSON.parse(options.body);
    const pageIndex = body.pageIndex;
    const pageSize = body.pageSize;
    const start = (pageIndex-1) * pageSize;
    const end = pageIndex * pageSize;
    const list = diaryList.slice(start,end);
    return{
        list: list,
        total: diaryList.length
    }
})

Mock.mock('/api/delete/diary','post',(options)=>{
    const body = JSON.parse(options.body);
    const index = diaryList.findIndex(item => item.id === body.id);
    diaryList.splice(index,1);
    const start = (body.pageIndex-1) * body.pageSize;
    const end = body.pageIndex * body.pageSize;
    const list = diaryList.slice(start,end);
    return{
        list: list,
        total: diaryList.length,
    }
})