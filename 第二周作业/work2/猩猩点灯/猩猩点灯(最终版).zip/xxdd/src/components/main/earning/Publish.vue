<template>
    <div class="wrapper">
      该页面正在开发中......
    </div>
</template>

<script>

export default {
  name: 'Publish',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5

</style>
