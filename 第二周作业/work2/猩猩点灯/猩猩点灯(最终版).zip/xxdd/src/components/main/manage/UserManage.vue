<template>
    <div class="wrapper">
      该页面正在开发中......
    </div>
</template>

<script>

export default {
  name: 'UserManage',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="stylus">
theme-color = #00c896
theme-hover-color = #e6faf5
border-color = #e6e6e6

.wrapper
  height 100%
  background-color #fff
  border 1px solid border-color
  border-radius 4px
  padding 20px
  box-sizing border-box
</style>
